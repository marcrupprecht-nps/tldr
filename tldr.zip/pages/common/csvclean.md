# csvclean

> Finds and cleans common syntax errors in CSV files.
> Included in csvkit.
> More information: <https://csvkit.readthedocs.io/en/latest/scripts/csvclean.html>.

- Clean a CSV file:

`csvclean {{bad.csv}}`

- List locations of syntax errors in a CSV file:

`csvclean -n {{bad.csv}}`
