# tldrl

> This command is an alias of `tldr-lint`.
> More information: <https://github.com/tldr-pages/tldr-lint>.

- View documentation for the original command:

`tldr tldr-lint`
