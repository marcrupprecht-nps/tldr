# pio init

> This command is an alias of `pio project init`.

- View documentation for the original command:

`tldr pio project`
