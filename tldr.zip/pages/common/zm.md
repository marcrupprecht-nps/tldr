# zm

> A tool for managing articles of newspapers and blogs.
> More information: <https://github.com/ZERMZeitung/zm2>.

- Make a new draft:

`zm new`

- Edit a draft:

`zm edit`

- Publish a draft and commit it with git:

`zm publish`
