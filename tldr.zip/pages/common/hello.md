# hello

> Print "Hello, world!", "hello, world" or a customizable text.
> More information: <https://www.gnu.org/software/hello/>.

- Print "Hello, world!":

`hello`

- Print "hello, world", the traditional type:

`hello --traditional`

- Print a text message:

`hello --greeting="{{greeting_text}}"`
