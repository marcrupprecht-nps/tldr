# wipeclean

> Clear the terminal screen using an animated wiper.
> More information: <https://github.com/JeanJouliaCode/wipeClean>.

- Clear the terminal screen:

`wipeclean`

- Set the animation speed in frames per second (defaults to 150):

`wipeclean --speed {{speed}}`
