# pueue status

> Display the current status of all tasks.
> More information: <https://github.com/Nukesor/pueue>.

- Show the status of all tasks:

`pueue status`

- Show the status of a specific group:

`pueue status --group {{group_name}}`
