# ntl

> This command is an alias of `netlify`.
> More information: <https://cli.netlify.com>.

- View documentation for the original command:

`tldr netlify`
