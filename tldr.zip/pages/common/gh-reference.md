# gh reference

> Display a reference about the GitHub CLI command.
> More information: <https://cli.github.com/manual/gh_help_reference>.

- Display a markdown reference of all `gh` commands:

`gh reference`
