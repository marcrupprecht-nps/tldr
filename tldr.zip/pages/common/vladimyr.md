# vladimyr

> Dario Vladović's personal CLI.
> More information: <https://github.com/vladimyr/vladimyr-cli>.

- Start Dario's interactive CLI:

`vladimyr`
