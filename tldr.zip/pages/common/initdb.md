# initdb

> Create a PostgreSQL database on disk.
> More information: <https://www.postgresql.org/docs/9.5/app-initdb.html>.

- Create a database at `/usr/local/var/postgres`:

`initdb -D /usr/local/var/postgres`
