# mkdir

> Erstellt einen neuen Ordner.

- Erstellt einen Ordner im aktuellen Verzeichnis:

`mkdir neuesVerzeichnis`

- Erstelle mehrere neue Ordner im aktuellen Verzeichnis:

`mkdir neuesVerzeichnis1 neuesVerzeichnis2 ...`

- Erstelle einen Ordner in einem anderen Verzeichnis:

`mkdir pfad/zum/neuenVerzeichnis`
