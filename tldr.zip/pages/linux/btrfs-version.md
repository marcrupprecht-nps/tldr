# btrfs version

> Display btrfs-progs version.
> More information: <https://btrfs.wiki.kernel.org/index.php/Manpage/btrfs>.

- Display btrfs-progs version:

`btrfs version`

- Display help:

`btrfs version --help`
