# clist

> This command is an alias of `choco list`.
> More information: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- View documentation for the original command:

`tldr choco list`
