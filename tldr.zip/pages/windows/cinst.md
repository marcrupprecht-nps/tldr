# cinst

> This command is an alias of `choco install`.
> More information: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- View documentation for the original command:

`tldr choco install`
