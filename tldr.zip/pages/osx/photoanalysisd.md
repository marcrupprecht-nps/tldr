# photoanalysisd

> This analyzes photo libraries for Memories, People, and scene or object based search.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/photoanalysisd/>.

- Start the daemon:

`photoanalysisd`
