# dalvikvm

> Android Java virtual machine.
> More information: <https://source.android.com/devices/tech/dalvik>.

- Start a Java program:

`dalvikvm -classpath {{path/to/file.jar}} {{classname}}`
