# line

> Read a single line of input.
> More information: <https://manned.org/line.1>.

- Read input:

`line`
