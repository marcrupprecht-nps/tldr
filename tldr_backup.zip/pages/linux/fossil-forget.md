# fossil forget

> This command is an alias of `fossil rm`, with the exception that it never removes files from the disk.
> More information: <https://fossil-scm.org/home/help>.

- View documentation for the original command:

`tldr fossil rm`
