# ncal

> This command is an alias of `cal`.
> More information: <https://manned.org/ncal>.

- View documentation for the original command:

`tldr cal`
