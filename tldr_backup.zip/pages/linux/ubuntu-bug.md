# ubuntu-bug

> This command is an alias of `apport-bug`.
> More information: <https://manned.org/ubuntu-bug>.

- View documentation for the original command:

`tldr apport-bug`
