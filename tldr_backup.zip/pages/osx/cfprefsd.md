# cfprefsd

> Provides preferences services (`CFPreferences`, `NSUserDefaults`).
> It should not be invoked manually.
> More information: <https://www.unix.com/man-page/osx/8/cfprefsd/>.

- Start the daemon:

`cfprefsd`
