# secd

> Controls access to and modification of keychain items.
> It should not be invoked manually.
> More information: <https://www.unix.com/man-page/mojave/8/secd>.

- Start the daemon:

`secd`
